package com.example.Login.data

import com.example.Login.model.Produto

class ListaProdutoMock() {

    var listaProdutoMock = ArrayList<Produto>()














}