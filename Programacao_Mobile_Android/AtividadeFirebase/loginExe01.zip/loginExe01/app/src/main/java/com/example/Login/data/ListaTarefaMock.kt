package com.example.Login.data

import com.example.Login.model.ListaTarefa

class ListaTarefaMock() {

    var listaTarefaMock = ArrayList<ListaTarefa>()




}