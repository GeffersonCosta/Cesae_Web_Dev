import { Component, inject } from '@angular/core';
import { ListaAnimaisComponent } from "../../components/lista-animais/lista-animais.component";
import { AnimaisService } from '../../services/animais.service';
import { Animal } from '../../models/animal';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-animais',
  standalone: true,
  imports: [ListaAnimaisComponent],
  providers: [],
  templateUrl: './animais.component.html',
  styleUrl: './animais.component.scss'
})
export class AnimaisComponent {
  //animais: Array<{id: number, nome: string, ...}> = [
  animais: Array<any> = [];
  
  constructor(private animaisService: AnimaisService) {
    //this.animais = animaisService.getAnimais()
    console.log(this.animais)
  }
  
  onClickAdd() {
    const animal: Animal = {
      id: 101,
      nome: 'Caril',
      especie: 'gato',
      dataNascimento: '2018-06-25',
      cor: 'amarelado'
    };
    this.animaisService.createAnimal(animal);
  }
}
