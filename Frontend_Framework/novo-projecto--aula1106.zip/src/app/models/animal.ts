export interface Animal {
  id?: number;
  nome: string;
  especie: string;
  dataNascimento: string;
  cor?: string;
  //OU   cor: string | undefined;
}
