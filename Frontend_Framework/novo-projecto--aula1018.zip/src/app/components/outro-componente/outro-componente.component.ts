import { Component } from '@angular/core';

@Component({
  selector: 'app-outro-componente',
  standalone: true,
  imports: [],
  templateUrl: './outro-componente.component.html',
  styleUrl: './outro-componente.component.scss'
})
export class OutroComponenteComponent {

}
