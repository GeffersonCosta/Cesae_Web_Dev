import { Component } from '@angular/core';

@Component({
  selector: 'app-ex02',
  standalone: true,
  imports: [],
  templateUrl: './ex02.component.html',
  styleUrl: './ex02.component.scss'
})
export class Ex02Component {

}
