import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutroCComponent } from './outro-c.component';

describe('OutroCComponent', () => {
  let component: OutroCComponent;
  let fixture: ComponentFixture<OutroCComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OutroCComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutroCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
