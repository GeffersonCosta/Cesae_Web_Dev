import { Component } from '@angular/core';

@Component({
  selector: 'app-outro-c',
  standalone: true,
  imports: [],
  templateUrl: './outro-c.component.html',
  styleUrl: './outro-c.component.scss'
})
export class OutroCComponent {

}
