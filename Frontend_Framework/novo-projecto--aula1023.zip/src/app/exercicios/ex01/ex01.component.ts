import { Component } from '@angular/core';

@Component({
  selector: 'app-ex01',
  standalone: true,
  imports: [],
  templateUrl: './ex01.component.html',
  styleUrl: './ex01.component.scss'
})
export class Ex01Component {

}
