{{-- @extends('layouts.femaster')

@section('content')
    <h4>Usuário deletado da base de dados:</h4>
    <p>{{ $serName->name }}</p>
    <p>{{ $serName->email }}</p>
@endsection --}}
