<?php $__env->startSection('content'); ?>
<?php
        $myvar = " ";
        $name = "Henrique";
    ?>
    <h5>Olá sou a nossa casa!</h5>
    <p><?php echo e($myFirstVar); ?></p>
    <ul>
        <?php $__currentLoopData = $weekDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($day); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php if($myvar): ?>
    <p><?php echo e($myvar); ?></p>
    <?php else: ?>
    <p>Não existe nome</p>
    <?php endif; ?>

    <h3>Dados do Curso</h3>
    <p>Nome: <?php echo e($info['name']); ?></p>
    <p>Horas: <?php echo e($info['hours']); ?></p>

    <img src="<?php echo e(asset('imagens/carro.jpg')); ?>" alt="">
    <ul>
        <li><a href="<?php echo e(route('welcome')); ?>">Welcome</a></li>
        <li><a href="<?php echo e(route('users.all')); ?>">all users</a></li>
        <li><a href="<?php echo e(route('users.add')); ?>">add users</a></li>
        <li><a href="<?php echo e(route('task.add')); ?>">Adicionar Tarefa</a></li>
        <li><a href="<?php echo e(route('all.Task')); ?>">Todas as Tarefas</a></li>

    </ul>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/utils/home.blade.php ENDPATH**/ ?>