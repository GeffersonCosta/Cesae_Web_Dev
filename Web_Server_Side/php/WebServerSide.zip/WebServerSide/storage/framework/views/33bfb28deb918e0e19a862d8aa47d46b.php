<?php $__env->startSection('content'); ?>
    <h4>Usuário deletado da base de dados:</h4>
    <p><?php echo e($serName->name); ?></p>
    <p><?php echo e($serName->email); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/users/delete_user.blade.php ENDPATH**/ ?>