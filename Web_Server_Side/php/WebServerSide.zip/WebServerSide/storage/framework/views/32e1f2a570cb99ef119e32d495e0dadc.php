<?php $__env->startSection('content'); ?>
<h1>Prendas de Natal e valor gasto</h1>
<br><br>
<table class="table">
    <thead>
      <tr>
        <th scope="col">Nome</th>
        <th scope="col">Valor Previsto</th>
        <th scope="col">Valor Gasto</th>
        <th scope="col">Quem irá ganhar</th>
        <th scope="col">Total</th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo e($gifts -> name); ?></td>
        <td><?php echo e($gifts -> value_predicted); ?></td>
        <td><?php echo e($gifts -> value_spent); ?>€</td>
        <td><?php echo e($userName -> username); ?></td>
        <td><?php echo e($valorTotal); ?>€</td>
        <td></td>
        <td></td>
      </tr>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/gifts/gift_show.blade.php ENDPATH**/ ?>