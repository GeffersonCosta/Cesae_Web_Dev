<?php $__env->startSection('content'); ?>
<h1>Prendas de Natal</h1>

<br><br>

<table class="table">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Nome</th>
        <th scope="col">Valor Previsto</th>
        <th scope="col">Valor Gasto</th>
        <th scope="col">Quem irá ganhar</th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $gifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($gift -> id); ?></th>
        <td><?php echo e($gift -> name); ?></td>
        <td><?php echo e($gift -> value_predicted); ?></td>
        <td><?php echo e($gift -> value_spent); ?></td>
        <td><?php echo e($gift -> username); ?></td>
        <td><a href="<?php echo e(route('gifts.gift_show', $gift->id)); ?>" class="btn btn-primary">Ver</a></td>
        <td><a href="<?php echo e(route('gifts.gift_delete', $gift->id)); ?>" class="btn btn-danger">Remover</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/gifts/gift.blade.php ENDPATH**/ ?>