<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Users</title>
</head>
<body>
    <h3>Add new User</h3>
    <ul>
        <li>Olá, aqui podes Adicionar Utilizadores</li>
    </ul>
</body>
</html>
<?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/newUsers/usersNew.blade.php ENDPATH**/ ?>