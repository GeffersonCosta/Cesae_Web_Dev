<?php $__env->startSection('content'); ?>
<?php
        $myvar = " ";
        $name = "Henrique";
    ?>
    <h5>Olá sou a nossa casa!</h5>
    <?php if($myvar): ?>
    <p><?php echo e($myvar); ?></p>
    <?php else: ?>
    <p>Não existe nome</p>
    <?php endif; ?>
    <img src="<?php echo e(asset('imagens/carro.jpg')); ?>" alt="">
    <ul>
        <li><a href="<?php echo e(route('welcome')); ?>">Welcome</a></li>
        <li><a href="<?php echo e(route('users.all')); ?>">all users</a></li>
        <li><a href="<?php echo e(route('newUser')); ?>">add users</a></li>
    </ul>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\wmd2024\Desktop\webserver-fazer-push-em-casa\WebServerSide\resources\views/utils/home.blade.php ENDPATH**/ ?>