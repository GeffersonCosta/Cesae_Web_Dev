<?php $__env->startSection('content'); ?>
    <h4>Dados do usuário <?php echo e($users->name); ?></h4>
    <h6><?php echo e($users->email); ?></h6>
    <h6><?php echo e($users->password); ?></h6>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/users/show_user.blade.php ENDPATH**/ ?>