<?php $__env->startSection('content'); ?>


<h1>Adicionar Task</h1>

<form method="POST" action="<?php echo e(route("task.create")); ?>">
    <?php echo csrf_field(); ?>
    <fieldset>
      <div class="mb-3">
        <label for="" class="form-label">Nome da Tarefa</label>
        <input type="text" name="name" id="" class="form-control" placeholder="Nome da Tarefa" required>
      </div>
      <div class="mb-3">
        <label for="" class="form-label">Descrição da Tarefa</label>
        <input type="text" name="description" id="" class="form-control" placeholder="Descrição da Tarefa" required>
      </div>
      <div class="mb-3">
        <select name="user_id" id="">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($user -> id); ?>"><?php echo e($user -> name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Enviar</button>
    </fieldset>
  </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/tasks/add_task.blade.php ENDPATH**/ ?>