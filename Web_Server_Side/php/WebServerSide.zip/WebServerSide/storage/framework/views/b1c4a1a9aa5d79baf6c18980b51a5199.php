<?php $__env->startSection('content'); ?>

        <h3>Sou uma blade para todos os users</h3><br><br>
        <?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($user -> id); ?></th>
                <td><?php echo e($user -> name); ?></td>
                <td><?php echo e($user -> email); ?></td>
                <td><?php echo e($user -> password); ?></td>
                <td><a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info">Ver</a></td>
                <td><a href="<?php echo e(route('users.delete', $user->id)); ?>" class="btn btn-danger">Apagar</a></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>




<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/users/all_users.blade.php ENDPATH**/ ?>