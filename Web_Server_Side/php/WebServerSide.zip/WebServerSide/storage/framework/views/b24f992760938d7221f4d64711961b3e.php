<?php $__env->startSection('content'); ?>


<h1>Adicionar usuário</h1>

<form method="POST" action="<?php echo e(route("users.create")); ?>">
    <?php echo csrf_field(); ?>
    <fieldset>
      <div class="mb-3">
        <label for="" class="form-label">Nome</label>
        <input type="text" name="name" id="" class="form-control" placeholder="Nome">
      </div>
      <div class="mb-3">
        <label for="disabledSelect" class="form-label">Email</label>
        <input type="text" name="email" id="" class="form-control" placeholder="Email">
      </div>
      <div class="mb-3">
      </div>
      <button type="submit" class="btn btn-primary">Enviar</button>
    </fieldset>
  </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\WebServerSide\resources\views/users/insert-user.blade.php ENDPATH**/ ?>