

@extends('layouts.fmaster')

@section('content')

<div class="container">
    <div>
        <h1>Olá {{$user}}</h1>
    </div>
</div>


@endsection
