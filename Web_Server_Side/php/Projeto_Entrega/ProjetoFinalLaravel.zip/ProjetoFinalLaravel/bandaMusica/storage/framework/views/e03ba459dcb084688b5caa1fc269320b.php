<?php $__env->startSection('content'); ?>


<h1>Adicionar Álbum</h1>

<form method="POST" action="<?php echo e(route('create.albums')); ?>" enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <fieldset>
      <div class="mb-3">
        <label for="name" class="form-label">Nome do álbum</label>
        <input type="text" name="name" id="name" class="form-control" placeholder="Nome" required>
      </div>
      <div class="mb-3">
        <label for="photo" class="form-label">Imagem</label>
        <input type="file" accept="image/*" name="photo" id="photo" class="form-control" required>
      </div>

      <div class="mb-3">
        <label for="select" class="form-label">Selecione a Banda</label>
        <select name="band_id" id="">
            <?php $__currentLoopData = $allBands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $band): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($band->id); ?>"><?php echo e($band->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>

      <div class="mb-3">
        <label for="date" class="form-label">Data de lançamento</label>
        <input type="date" name="date" id="date" class="form-control">
      </div>

      <button type="submit" class="btn btn-primary">Enviar</button>
    </fieldset>
  </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/albums/add_albums.blade.php ENDPATH**/ ?>