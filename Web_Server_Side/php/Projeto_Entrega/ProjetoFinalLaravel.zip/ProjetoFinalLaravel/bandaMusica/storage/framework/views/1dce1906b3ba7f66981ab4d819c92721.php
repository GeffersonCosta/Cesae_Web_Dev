<?php $__env->startSection('content'); ?>


<h1>Todos os albuns da Banda XXXXX</h1> 

<table class="table table-striped table-bordered">
    <thead>
        <tr>
        <th scope="col">id</th>
        <th scope="col">Nome do album</th>
        <th scope="col">imagem</th>
        <th scope="col">Data de lançamento</th>
        </tr>
    </thead>
    <tbody>
        
        <tr>
            
            <td>1</td>
            <td>Ten</td>
            <td><img width="40px" height="40px" style="border-radius: 50% "asset('images/profile.png') }}"></td>
            <td>27/08/1991</td>
            <td>
                <a href="" class="btn btn-info">Editar</a>
                <a href="" class="btn btn-danger">Apagar</a>
                
            </td>
            </tr>
        
    </tbody>
</table>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/albums/albums.blade.php ENDPATH**/ ?>