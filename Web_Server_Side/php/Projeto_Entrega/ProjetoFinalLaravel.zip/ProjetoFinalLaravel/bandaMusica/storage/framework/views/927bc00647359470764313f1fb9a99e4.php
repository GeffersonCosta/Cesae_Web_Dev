<?php $__env->startSection('content'); ?>

<div class="container">
    <div>
        <h1>Olá <?php echo e($user); ?></h1>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>