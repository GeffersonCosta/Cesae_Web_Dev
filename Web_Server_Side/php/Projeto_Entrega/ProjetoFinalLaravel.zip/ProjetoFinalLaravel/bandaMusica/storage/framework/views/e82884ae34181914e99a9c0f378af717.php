<?php $__env->startSection('content'); ?>



<h1>Adicionar Banda</h1>

<form method="POST" action="<?php echo e(route('create.bands')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <fieldset>

      <div class="mb-3">
        <label for="name" class="form-label">Nome da Banda</label>
        <input type="text" name="name" id="name" class="form-control"  placeholder="Nome da Banda" required>
      </div>
      <div class="mb-3">
        <label for="photo" class="form-label">Photo</label>
        
        <input type="file" accept="image/*" name="photo" id="photo"  class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary">Enviar</button>
    </fieldset>
  </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/bands/add_bands.blade.php ENDPATH**/ ?>