<?php $__env->startSection('content'); ?>


<h1>Todos os albuns da Banda <?php echo e($band->name); ?></h1> 

<table class="table table-striped table-bordered">
    <thead>
        <tr>
        <th scope="col">Nome do album</th>
        <th scope="col">imagem</th>
        <th scope="col">Data de lançamento</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $allAlbums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td scope="row"><?php echo e($album -> name); ?></td>
            <td>
            <img
            src="<?php echo e($album->photo ? asset('storage/' . $album->photo) : ''); ?>">
            </td>
            <td><?php echo e($album -> due_at); ?></td>
            <?php if(auth()->guard()->check()): ?>
            <td>
                <a href="<?php echo e(route('update.album', $album -> id)); ?>" class="btn btn-success">Editar</a>
                <?php if(Auth::User()->user_type == 0): ?>
                <a href="<?php echo e(route('delete.Album', $album -> id)); ?>" class="btn btn-danger">Apagar</a>
                
                <?php endif; ?>
            </td>
            <?php endif; ?>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/albums/all_albums.blade.php ENDPATH**/ ?>