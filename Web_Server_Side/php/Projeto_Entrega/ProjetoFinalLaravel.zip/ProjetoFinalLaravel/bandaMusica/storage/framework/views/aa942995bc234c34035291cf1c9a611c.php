<?php $__env->startSection('content'); ?>


<h1>Todas as Bandas</h1>

<table class="table table-striped table-bordered">
    <thead>
        <tr>
        <th scope="col">Nome da banda</th>
        <th scope="col">Foto</th>
        <th scope="col">número de álbuns</th>
        </tr>
    </thead>
    <tbody>
         <?php $__currentLoopData = $allBands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $band): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($band -> name); ?></td>
            <td>
                <img width="40%" style="border-radius: 10%"
                src="<?php echo e($band->photo ? asset('storage/' . $band->photo) : asset('images/profile.png')); ?>">
            </td>
            <td><?php echo e($band->amount_albums); ?></td>
            <td>
                <a href="<?php echo e(route('all.albums', $band -> id)); ?>" class="btn btn-info">Ver álbuns</a><br>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::User()->user_type == 0): ?>
                <a href="<?php echo e(route('delete.band', $band -> id)); ?>" class="btn btn-danger">Apagar</a>
                <?php endif; ?>
                <a href="<?php echo e(route('update.band', $band -> id)); ?>" class="btn btn-success">Editar</a>
                
                <?php endif; ?>
            </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/bands/all_bands.blade.php ENDPATH**/ ?>