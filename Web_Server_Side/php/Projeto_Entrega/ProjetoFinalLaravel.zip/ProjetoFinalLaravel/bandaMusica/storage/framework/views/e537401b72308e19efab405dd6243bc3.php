<?php $__env->startSection('content'); ?>



<h1>Atualizar Banda</h1>

<form method="POST" action="<?php echo e(route('create.bands')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <fieldset>
      <input type="hidden" name="id" value="<?php echo e(isset($band) ? $band->id : ''); ?>">
      <div class="mb-3">
        <label for="name" class="form-label">Nome da Banda</label>
        <input type="text" value="<?php echo e(isset($band) ? $band->name : ''); ?>" name="name" id="name" class="form-control"   required>
      </div>
      <div class="mb-3">

        <img width="150px" style="border-radius: 10%"
        src="<?php echo e($band->photo ? asset('storage/' . $band->photo) : ''); ?>"><br>
        <label for="photo" class="form-label">Photo</label>
        <input type="file" accept="image/*" name="photo" id="photo"  class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary">Enviar</button>
    </fieldset>
  </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/bands/update_band.blade.php ENDPATH**/ ?>