<?php $__env->startSection('content'); ?>


<h1>Adicionar usuário</h1>
<form method="POST" action="<?php echo e(route("users.create")); ?>">

    <?php echo csrf_field(); ?>
    <fieldset>
      <div class="mb-3">
        <label for="" class="form-label">Nome</label>
        <input type="text" name="name" id="" class="form-control" placeholder="Nome" required>
      </div>
      <div class="mb-3">
        <label for="" class="form-label">Email</label>
        <input type="text" name="email" id="" class="form-control" placeholder="Email" required>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        Email ou password incorreto
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="" class="form-label">Password</label>
        <input type="password" name="password" id="" class="form-control" placeholder="password" required min="6">
      </div>
      <button type="submit" class="btn btn-primary">Enviar</button>
    </fieldset>
  </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\geffe\OneDrive\Ambiente de Trabalho\Cesae_Web_Dev\Web_Server_Side\php\ProjetoFinalLaravel\bandaMusica\resources\views/users/add_user.blade.php ENDPATH**/ ?>